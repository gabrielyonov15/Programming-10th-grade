﻿namespace SuzdavaneNaOpashkaIUpravlenieNaZayavki
{
    using System;
    using System.Collections.Generic;
    class Program
    {
        static void Main()
        {
            Queue<CustomerRequest> opashkaZaZayavki = new Queue<CustomerRequest>();
            int sledvashtoId = 1;
            bool izhod = false;
            while (!izhod)
            {
                Console.WriteLine("1. Добавяне на нова заявка");
                Console.WriteLine("2. Обработка на следващата заявка");
                Console.WriteLine("3. Преглед на всички заявки");
                Console.WriteLine("4. Изход");
                Console.Write("Изберете опция: ");
                string izbor = Console.ReadLine();
                switch (izbor)
                {
                    case "1":
                        DovavqneNaNovaZayavka(opashkaZaZayavki, ref sledvashtoId);
                        break;
                    case "2":
                        ObraboteteSledvashtataZayavka(opashkaZaZayavki);
                        break;
                    case "3":
                        VizhVsichkiZayavki(opashkaZaZayavki);
                        break;
                    case "4":
                        izhod = true;
                        break;
                    default:
                        Console.WriteLine("Невалидна опция. Моля, опитайте отново.");
                        break;
                }
                Console.WriteLine();
            }
        }
        static void DovavqneNaNovaZayavka(Queue<CustomerRequest> queue, ref int sledvashtoId)
        {
            Console.Write("Въведете име на клиента: ");
            string ime = Console.ReadLine();
            Console.Write("Въведете детайли за заявката: ");
            string zayavetePodrobnosti = Console.ReadLine();
            CustomerRequest novaZayavka = new CustomerRequest(sledvashtoId, ime, zayavetePodrobnosti);
            queue.Enqueue(novaZayavka);
            sledvashtoId++;
            Console.WriteLine("Заявката е добавена успешно!");
        }
        static void ObraboteteSledvashtataZayavka(Queue<CustomerRequest> queue)
        {
            if (queue.Count > 0)
            {
                CustomerRequest novaZayavka = queue.Dequeue();
                Console.WriteLine("Обработва се следната заявка:");
                Console.WriteLine(novaZayavka);
            }
            else
            {
                Console.WriteLine("Няма налични заявки за обработка.");
            }
        }
        static void VizhVsichkiZayavki(Queue<CustomerRequest> queue)
        {
            if (queue.Count > 0)
            {
                Console.WriteLine("Текущи заявки:");
                foreach (CustomerRequest zayavka in queue)
                {
                    Console.WriteLine(zayavka);
                }
            }
            else
            {
                Console.WriteLine("Няма налични заявки.");
            }
        }
    }
}
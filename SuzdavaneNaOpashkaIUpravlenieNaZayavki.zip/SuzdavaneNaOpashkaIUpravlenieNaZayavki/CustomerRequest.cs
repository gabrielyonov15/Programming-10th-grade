﻿using System;
using System.Collections.Generic;
using System.Diagnostics.Metrics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;

namespace SuzdavaneNaOpashkaIUpravlenieNaZayavki
{
    public class CustomerRequest
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public string RequestDetails { get; set; }

        public CustomerRequest(int id, string name, string requestDetails)
        {
            Id = id;
            Name = name;
            RequestDetails = requestDetails;
        }

        public override string ToString()
        {
            return $"{Name} - {RequestDetails}";
        }
    }

}